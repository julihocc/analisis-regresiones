# Matemáticas para la ciencia de datos
## Regresiones lineales simples
### Centro Turing



Vamos a discutir los siguientes temas: 
1. Entender qué problemas puede resolver el aprendizaje automático
2. Qué problemas puede resolver un modelo de regresiónLos puntos fuertes y débiles de la correlación
3. Cómo se extienden las correlaciones a un modelo de regresión simple
4. Cuándo, qué y porqué del modelo de regresión
5. Las matemáticas esenciales detrás del método de gradiente

En el proceso, utilizaremos cierta terminología y conceptos estadísticos para ofrecerle la perspectiva de la regresión lineal en el marco más amplio de la estadística, aunque nuestro enfoque seguirá siendo práctico.

### Definición del problema 
El aprendizaje automático tiene sólidas raíces en años de investigación: realmente ha sido un largo viaje desde finales de los años cincuenta, cuando Arthur Samuel aclaró que el aprendizaje automático era un "campo de estudio que da a los ordenadores la capacidad de aprender sin ser explícitamente programados".

En general, los algoritmos de aprendizaje automático pueden aprender de tres maneras:

1. Aprendizaje supervisado: Es cuando presentamos ejemplos etiquetados para aprender. 
2. Aprendizaje no supervisado: Es cuando presentamos ejemplos sin ninguna pista, dejando dejar que el algoritmo cree una etiqueta. 
3. Aprendizaje por refuerzo: Es cuando presentamos ejemplos sin etiquetas, como en el aprendizaje no supervisado, pero obtenemos información del entorno sobre si la suposición de la etiqueta es correcta o no.

El aprendizaje no supervisado tiene importantes aplicaciones en la visión robótica y la creación de características automáticas, y el aprendizaje por refuerzo es fundamental para el desarrollo de la IA autónoma (por ejemplo, en robótica, pero también en la creación de agentes de software inteligentes).

Sin embargo, el aprendizaje supervisado es el más importante en la ciencia de los datos porque nos permite hacer predicciones. 

#### Notación

* En el formalismo matemático, llamamos al resultado que queremos predecir la respuesta o variable objetivo y solemos etiquetarla con la letra minúscula $y$.
* En cambio, las premisas se denominan variables predictivas, o simplemente atributos o características, y se etiquetan con una x minúscula si hay una sola y con una X mayúscula si hay muchas.
* Con letras mayúsculas denotaremos matrices, incluídos los vectores que, técnicamente son matrix columnas (o renglones).
* También es importante tener siempre en cuenta las dimensiones de X e y; así, por convención, podemos llamar n al número de observaciones y p al número de variables.

#### Vectores y matrices con Numpy

Todos los datos los representaremos en forma de matrices. Ahora mostraremos algunas formas de construir matrices (y vectores) con `numpy`.


```python
# vector a partir de listas
import numpy as np

vector = np.array([1,2,3,4,5])
print(vector)
print(vector.shape)
```

    [1 2 3 4 5]
    (5,)
    


```python
vector_columna = vector.reshape((5,1))
print(vector_columna)
print(vector_columna.shape)
```

    [[1]
     [2]
     [3]
     [4]
     [5]]
    (5, 1)
    


```python
vector_renglon = vector.reshape((1,5))
print(vector_renglon)
print(vector_renglon.shape)
```

    [[1 2 3 4 5]]
    (1, 5)
    


```python
# es posible crear matrices de manera aleatoria

np.random.seed(0)

print(np.random.randint(10, size=(2,2)))
print(np.random.normal(0, 10, size=(2,2)))
print(np.random.binomial(10, .25, size=(2,2)))
print(np.random.poisson(10, size=(2,2)))
```

    [[5 0]
     [3 3]]
    [[  3.70255385  10.40530751]
     [-15.16982735  -8.66276211]]
    [[1 2]
     [2 4]]
    [[10 14]
     [11 17]]
    


```python
# existen otras maneras de crear matrices
print(np.zeros((5,2)), "\n")
print(np.ones((5)), "\n")
print(np.array(range(20)).reshape((5,4)), "\n")
```

    [[0. 0.]
     [0. 0.]
     [0. 0.]
     [0. 0.]
     [0. 0.]] 
    
    [1. 1. 1. 1. 1.] 
    
    [[ 0  1  2  3]
     [ 4  5  6  7]
     [ 8  9 10 11]
     [12 13 14 15]
     [16 17 18 19]] 
    
    

### La familia de modelos lineales

En estadística, la familia de modelos lineales se denomina modelo lineal generalizado (MLG). Mediante transformaciones, restricciones y métodos de optimización, los MLG pueden resolver una amplia gama de problemas diferentes.

En este curso, no nos extenderemos más allá de lo necesario para el campo estadístico. Sin embargo, propondremos un par de modelos de la gran familia de los MLG, a saber, la regresión lineal y la regresión logística; ambos métodos son apropiados para resolver los dos problemas más básicos de la ciencia de los datos: la regresión y la clasificación.

### Preparación para descubrir una regresión lineal simple

Un conjunto de datos es una estructura de datos que contiene variables de predicción y, a veces, de respuesta. A efectos de aprendizaje automático, puede estructurarse en forma de matriz, en forma de tabla con filas y columnas.

Para la presentación inicial de la regresión lineal en su versión simple (utilizando sólo una variable predictiva para pronosticar la variable de respuesta), hemos elegido un par de conjuntos de datos relativos a la evaluación inmobiliaria.

El primer conjunto de datos es conocido. Tomado del artículo de 
    *Harrison, D. y Rubinfeld, D.L. Hedonic Housing Prices and the Demand for Clean Air (J. Environ. Economics & Management, vol.5, 81-102, 1978)*, 
el conjunto de datos puede encontrarse en muchos paquetes de análisis y está presente en el sitio web de la U.S. paquetes de análisis y está presente en el UCI Machine Learning Repository (https://archive.ics.uci.edu/ml/datasets/Housing).

El conjunto de datos está formado por 506 secciones censales de Boston del censo de 1970 y presenta 21 variables relativas a diversos aspectos que pueden influir en el valor de los inmuebles. El objetivo es el valor monetario medio de las viviendas, expresado en miles de dólares. 

Entre las características disponibles, hay algunas bastante obvias, como el número de habitaciones, la antigüedad de los edificios y los niveles de delincuencia en el barrio, y otras menos obvias, como la concentración de contaminación, la disponibilidad de escuelas cercanas escuelas, el acceso a las autopistas y la distancia a los centros de trabajo.

El segundo conjunto de datos del repositorio Statlib de la Universidad Carnegie Mellon (https://archive.ics.uci.edu/ml/datasets/Housing) contiene 20.640 observaciones derivadas del censo de Estados Unidos de 1990.

* Cada observación es una serie de estadísticas (9 variables predictivas) de un grupo de bloques, es decir, aproximadamente 1.425 personas que viven en una zona geográficamente compacta. 
* La variable objetivo es un indicador del valor de la vivienda de ese bloque (técnicamente es el logaritmo natural del valor medio de la vivienda en el momento del censo). 
* Las variables predictoras son básicamente la mediana de los ingresos.


```python
"""
Importaremos ambos conjuntos para su análisis
"""
# el conjunto de California tiene que descargarse
from sklearn.datasets import fetch_california_housing
california = fetch_california_housing()
type(california)
```




    sklearn.utils.Bunch




```python
# el conjunto de Boston ya está incluido
# es en este conjunto en el que nos enfocaremos
from sklearn.datasets import load_boston
boston = load_boston()
type(boston)
```




    sklearn.utils.Bunch




```python
"""
Importaremos los paquetes necesarios
1. numpy: análisis numérico
2. pandas: marcos de datos
3. matplotlib: trazo de gráficas
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```


```python
# convertimos los datos de Boston en un marco de datos
dataset = pd.DataFrame(boston.data, columns=boston.feature_names)
dataset['target'] = boston.target
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>B</th>
      <th>LSTAT</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0.0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1.0</td>
      <td>296.0</td>
      <td>15.3</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0.0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2.0</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0.0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2.0</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0.0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3.0</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0.0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3.0</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.2</td>
    </tr>
  </tbody>
</table>
</div>



Aunque una regresión lineal es simple, en realidad el modelo más sencillo es *la media* aritmética. Sin embargo, esta sólo funciona relativamente bien si los datos están normalmente distribuidos. 


```python
"""
Densidad normal y su implementación en Python
"""
# pyplot será nuestra herramienta básica para graficar
import matplotlib.pyplot as plt
# un viejo conocido
import numpy as np
# importamos la clase que modela las variables normales
from scipy.stats import norm
```


```python
"""
Forma de la función de densidad normal
"""
# linspace(a,b,n) crea una malla de punto desde a hasta b
# separados por n subintervalos
x = np.linspace(-4,4,100)
# trazaremos las gráficas de la distribución normar para diferentes parámetros
for mean, variance in [(0,0.7),(0,1),(1,1.5),(-2,0.5)]:
    # pdf = probability density function
    # es la función puntual de probabilidad
    y = norm(loc=mean,scale=variance).pdf(x)
    plt.plot(x,y)
plt.show()
```


    
![png](output_29_0.png)
    



```python
"""
Trazamos el histograma de la variable objetivo del marco de datos
"""
dataset["target"].plot(
    kind="hist"
)
```




    <AxesSubplot:ylabel='Frequency'>




    
![png](output_30_1.png)
    



```python
"""
Ahora, bosquejemos una función de densidad aproximada
"""
dataset["target"].plot(
    kind="kde"
)
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_31_1.png)
    



```python
from scipy.stats import skew,kurtosis
info = """
Estadísticos 
{}

Asimetría (Skewness): {}
Curtosis (Kurtosis):{}
""".format(dataset["target"].describe(),
      #dataset["target"].skew(),
        skew(dataset["target"]),
      #dataset["target"].kurtosis())
           kurtosis(dataset["target"], fisher=True)
          )
print(info)
```

    
    Estadísticos 
    count    506.000000
    mean      22.532806
    std        9.197104
    min        5.000000
    25%       17.025000
    50%       21.200000
    75%       25.000000
    max       50.000000
    Name: target, dtype: float64
    
    Asimetría (Skewness): 1.104810822864635
    Curtosis (Kurtosis):1.4686287722747462
    
    

Como podemos observar, la distrbución tiene *asimetría positiva* y *leptocurtosis*. Para más detalles de este concepto consulta [Kurtosis() & Skew() Function In Pandas](https://medium.com/@atanudan/kurtosis-skew-function-in-pandas-aa63d72e20de) y la documentación correspondiente de Scipy para las funciones [skew()](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.skew.html) y [kurtosis()](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.kurtosis.html).

Ahora podemos evaluar los resultados midiendo el error producido en la predicción de los valores reales de "y" por esta regla. La estadística sugiere que, para medir la diferencia entre la predicción y el valor real, debemos elevar al cuadrado las diferencias y luego sumarlas todas. Este se denomina suma de errores al cuadrado:


```python
# pd.Series nos permite tratar una columna como una Serie de datos
# en la que podemos aplicar directamente operadores como la exponenciación
mean_expected_value = dataset["target"].mean()
print(mean_expected_value)
Squared_errors = pd.Series(dataset['target']-mean_expected_value)**2
SSE = np.sum(Squared_errors)
print('Sum of Squared Errors (SSE): {:.1f}'.format(SSE))
```

    22.532806324110698
    Sum of Squared Errors (SSE): 42716.3
    


```python
"""
Generaremos un histograma para analizar la distribución de los errores cuadráticos
"""
density_plot = Squared_errors.plot(
    kind='hist', 
    bins=range(0, 800, 30)
)
```


    
![png](output_36_0.png)
    


# Como medir las relaciones lineales

En estadística, hay una cantidad que ayuda a medir cómo se relacionan dos variables: **la correlación.**

Primero estandarizaremos las variables de la siguiente manera $$x=\frac{x-\bar{x}}{\sigma}$$


```python
"""
En Python se puede lograr vía la siguiente función

La desviación estándar, denotada por la letra griega sigma es la raíz cuadrada 
de la media de las desviaciones al cuadrado de la media, es decir, 
std = sqrt(mean(x)), where x = abs(a - a.mean())**2.

En Numpy, está implementada como la función std()
"""

def standardize(x):
    return (x-np.mean(x))/np.std(x)
```

A continuación definimos la covarianza, la cual será positiva si la relación es directa (cuando $x$ crece también $y$ lo hace) y si es negativa, la relación es indirecta (cuando $x$ crece, $y$ decrece). Definimos la covarianza como

$$cov(x,y)=\frac{1}{n} \sum(x-\bar{x})(y-\bar{y})$$


```python
"""
Implementación de la covarianza en Python
"""
def covariance(variable_1, variable_2, bias=0):
    observations = float(len(variable_1))
    delta_1 = variable_1 - np.mean(variable_1)
    delta_2 = variable_2 - np.mean(variable_2)    
    return np.sum(delta_1*delta_2)/(observations-int(bias))
```

Finalmente definimos el coeficiente $r$ correlación de Pearson, cuyas propiedas más relevantes son 
1. El valor del índice de correlación varía en el intervalo \[-1,1\], indicando el signo el sentido de la relación:
2. Si r=1, existe una correlación positiva perfecta. El índice indica una dependencia total entre las dos variables denominada relación directa: cuando una de ellas aumenta, la otra también lo hace en proporción constante.
3. Si 0<r<1 entonces existe una correlación positiva.
4. Si r=0 entonces no existe relación lineal pero esto no necesariamente implica que las variables son independientes: pueden existir todavía relaciones no lineales entre las dos variables.
5. Si -1<r<0, existe una correlación negativa.
6. Si r=-1, existe una correlación negativa perfecta. El índice indica una dependencia total entre las dos variables llamada relación inversa: cuando una de ellas aumenta, la otra disminuye en proporción constante.

Esta correlación se define como 
$$r(x,y)=\frac{1}{n} \frac{\sum(x-\bar{x})(y-\bar{y})}{\sigma_x \sigma_y}$$

Sin embargo, observa que se puede definir de manera equivalente a partir de la covarianza y de la de estandarización:


```python
"""
Implementaremos la correlación de Pearson de la siguiente manera:
"""
def correlation(var1,var2,bias=False):
    return covariance(standardize(var1), standardize(var2), bias)
```


```python
"""
Ahora calcularemos nuestra implementación en el ejemplo anterior 
y la compararemos con las funciones propias de Scipy
"""
from scipy.stats.stats import pearsonr
r = correlation(dataset["RM"], dataset["target"])
# {dato:.5f} nos permite inserta el dato que ingresamos como argumento en format() 
# con cinco decimates de precisión
print("Nuestra estimación del coeficiente de correlación: r={dato:.5f}".format(dato=r))
r_sp, _ = pearsonr(dataset["RM"], dataset["target"])
print("Estimación del coeficiente desde Scipy: r={dato:.5f}".format(dato=r_sp))
```

    Nuestra estimación del coeficiente de correlación: r=0.69536
    Estimación del coeficiente desde Scipy: r=0.69536
    


```python
"""
Graficaremos el diagrama de dispersión para visualizar los resultados
"""
x_range = [dataset["RM"].min(), dataset["RM"].max()]
y_range = [dataset["target"].min(), dataset["target"].max()]
scatter_plot = dataset.plot(
    kind="scatter", x="RM", y="target",
    xlim = x_range, 
    ylim = y_range
)

media_Y = scatter_plot.plot(
    x_range, 
    [dataset["target"].mean(), dataset["target"].mean()], 
    "--",
    color="red", 
    linewidth=2
)

media_X = scatter_plot.plot(
    [dataset["RM"].mean(), dataset["RM"].mean()], 
    y_range, 
    "--",
    color="green", 
    linewidth=2
)
```


    
![png](output_45_0.png)
    


**¿Qué implicación tiene la correlación que obtuvimos anteriormente, con la distribución de los puntos cuadrante a cuadrante?**

### Regresiones lineales con Statsmodels

Formalmente una regresión lineal es una relación de la forma
$$y =  \beta X  + \beta_0$$
donde
* $y$ es un vector columna con registros de la predicción
* $\beta, \beta_0$ escalares
* $X$ es un vector columna con resgistros del predictor
* $\beta_0$ conoce como *sesgo*

Existen dos métodos para generar regresiones lineales con el paquete `Statsmodels`:
1. `statsmodels.api`: Funciona con variables predictoras y de respuesta distintas y requiere que se defina cualquier transformación de las variables en la variable predictora, incluyendo la adición del intercepto
2. `statsmodels.formula.api`: Funciona de forma similar a R, permitiendo especificar una forma funcional (la fórmula de la suma de los predictores)

Ilustraremos nuestro ejemplo usando el statsModels.api; sin embargo, también mostraremos un método alternativo con statsmodels.formula.api.


```python
"""
Importaremos ambos módulos y definiremos las variables
"""

import statsmodels.api as sm
import statsmodels.formula.api as smf

y = dataset['target']
X = dataset['RM']
print(X)

```

    0      6.575
    1      6.421
    2      7.185
    3      6.998
    4      7.147
           ...  
    501    6.593
    502    6.120
    503    6.976
    504    6.794
    505    6.030
    Name: RM, Length: 506, dtype: float64
    


```python
# La variable X debe ampliarse con un valor constante; 
# el sesgo se calculará en consecuencia.
X = sm.add_constant(X)
print(X)
```

         const     RM
    0      1.0  6.575
    1      1.0  6.421
    2      1.0  7.185
    3      1.0  6.998
    4      1.0  7.147
    ..     ...    ...
    501    1.0  6.593
    502    1.0  6.120
    503    1.0  6.976
    504    1.0  6.794
    505    1.0  6.030
    
    [506 rows x 2 columns]
    

Como mencionamos, la fórmula de regresión es $y =  X \beta + \beta_0$, pero al hacer la transformación anterior se reduce a $y= (1:X)(\beta_0, \beta)'=\bar{X}\bar{\beta}$.


```python
"""
Implementación de la regresión con SMF. 

Esta sintaxis es más parecida a R, pero no la ocuparemos en resto de la unidad. 
"""
linear_regression = smf.ols(formula='target ~ RM', data=dataset)
fitted_model = linear_regression.fit()
```


```python
"""
Implementación con SM
"""
linear_regression = sm.OLS(y,X)
fitted_model = linear_regression.fit()
# imprimimos un resumen de los parámetros y estadísticos de la regresión
fitted_model.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>target</td>      <th>  R-squared:         </th> <td>   0.484</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.483</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   471.8</td>
</tr>
<tr>
  <th>Date:</th>             <td>Thu, 01 Jul 2021</td> <th>  Prob (F-statistic):</th> <td>2.49e-74</td>
</tr>
<tr>
  <th>Time:</th>                 <td>19:49:38</td>     <th>  Log-Likelihood:    </th> <td> -1673.1</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   506</td>      <th>  AIC:               </th> <td>   3350.</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   504</td>      <th>  BIC:               </th> <td>   3359.</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
    <td></td>       <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th> <td>  -34.6706</td> <td>    2.650</td> <td>  -13.084</td> <td> 0.000</td> <td>  -39.877</td> <td>  -29.465</td>
</tr>
<tr>
  <th>RM</th>    <td>    9.1021</td> <td>    0.419</td> <td>   21.722</td> <td> 0.000</td> <td>    8.279</td> <td>    9.925</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>102.585</td> <th>  Durbin-Watson:     </th> <td>   0.684</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td> 612.449</td> 
</tr>
<tr>
  <th>Skew:</th>          <td> 0.726</td>  <th>  Prob(JB):          </th> <td>1.02e-133</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 8.190</td>  <th>  Cond. No.          </th> <td>    58.4</td> 
</tr>
</table><br/><br/>Notes:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




```python
"""
La información de mayor interés para nosotros es los coefientes y las predicciones
"""
print(fitted_model.params)
betas = np.array(fitted_model.params)
fitted_values = fitted_model.predict(X)
print(fitted_values)
```

    const   -34.670621
    RM        9.102109
    dtype: float64
    0      25.175746
    1      23.774021
    2      30.728032
    3      29.025938
    4      30.382152
             ...    
    501    25.339584
    502    21.034286
    503    28.825691
    504    27.169108
    505    20.215096
    Length: 506, dtype: float64
    


```python
"""
Un valor importante a considerar es `R-squared`. Este es el coeficiente de determinación, 
una medida de lo bien que lo hace la regresión con respecto a una media simple. 
También se puede calcular de la siguiente manera:
"""
mean_sum_squared_errors = np.sum((dataset['target']-dataset['target'].mean())**2)
regr_sum_squared_errors = np.sum((dataset['target']-fitted_values)**2)
r2 = (mean_sum_squared_errors-regr_sum_squared_errors) / mean_sum_squared_errors
print(np.round(r2, 3))
```

    0.484
    

Para ahondar en la deficinión del valor R-cuadrada, consulta los siguientes artículos:
* [R-Squared Definition](https://www.investopedia.com/terms/r/r-squared.asp)
* [R-Squared vs. Adjusted R-Squared: What's the Difference?](https://www.investopedia.com/ask/answers/012615/whats-difference-between-rsquared-and-adjusted-rsquared.asp)

Para más detalles sobre el significado de los diferentes parámetros y estadísticos del resumen, consulta el documento adjunto que te proporcionamos. 


```python
"""
Observación: La media siempre está contenida en la regresión lineal
"""
X_mean = np.mean(X).to_numpy()
print(X_mean)
y_mean = np.mean(y)
print(y_mean)
print(fitted_model.predict(X_mean))
```

    [1.         6.28463439]
    22.532806324110698
    [22.53280632]
    


```python
"""
Observa que para algunos valores de x, la predicción se vuelve negativa
"""
fitted_model.predict([1,1])
```




    array([-25.5685118])



Esto nos deja una importante lección: **Una regresión lineal siempre puede trabajar dentro del rango de valores que aprendió (esto se llama interpolación) pero puede proporcionar valores correctos para sus límites de aprendizaje (una actividad predictiva diferente llamada extrapolación) sólo en determinadas condiciones.**


```python
scatter_plot = dataset.plot(
    kind="scatter", x="RM", y="target",
    xlim = x_range, 
    ylim = y_range
)

scatter_plot.plot(
    dataset["RM"], fitted_values,     
    "--",
    color="red", 
    linewidth=2
)
```




    [<matplotlib.lines.Line2D at 0x26cea743dc0>]




    
![png](output_62_1.png)
    


### Evaluación de los valores ajustados

Existen algunos problemas a los que debemos estar atento:
1. **Valores demasiado alejados de la media.** Los residuos estandarizados grandes indican una grave dificultad al modelar dichas observaciones. Además, en el proceso de aprendizaje de estos valores, *los coeficientes de regresión pueden haber sido distorsionados.*
2. La varianza no homogénea señala que la regresión no funciona correctamente cuando el predictor tiene determinados valores.
3. Las formas extrañas en la nube de puntos residuales pueden indicar que se necesita un modelo más complejo para los datos que estás analizando.

En nuestro caso, podemos calcular fácilmente los residuos restando los valores ajustados de la
y luego trazando los residuos estandarizados resultantes en un gráfico.


```python
# Los residuales son la diferencia entre los datos y los valores ajustados
residuals = dataset['target']-fitted_values
# Normalizamos los residuales para entender su comportamiento estadístico
# respecto a la regresión lineal
normalized_residuals = standardize(residuals)
# En este caso, las unidades son deviaciones estándar
normalized_residuals.describe()
```




    count    5.060000e+02
    mean    -1.237482e-16
    std      1.000990e+00
    min     -3.535612e+00
    25%     -3.858019e-01
    50%      1.359408e-02
    75%      4.521429e-01
    max      5.971939e+00
    dtype: float64




```python
residual_scatter_plot = plt.plot(dataset['RM'],
                                 normalized_residuals,'bp')
mean_residual = plt.plot([int(x_range[0]),round(x_range[1],0)], [0,0], '-',
                         color='red', linewidth=2)
upper_bound = plt.plot([int(x_range[0]),round(x_range[1],0)], [3,3], '--',
                       color='red', linewidth=1)
lower_bound = plt.plot([int(x_range[0]),round(x_range[1],0)], [-3,-3], '--', 
                       color='red', linewidth=1)
plt.grid()
```


    
![png](output_66_0.png)
    



```python
# Histograma de los residuales normalizados
normalized_residuals.plot.hist()
```




    <AxesSubplot:ylabel='Frequency'>




    
![png](output_67_1.png)
    



```python
# Trazamos una función aproximada de densidad
normalized_residuals.plot.kde()
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_68_1.png)
    


El gráfico de dispersión resultante indica que los residuos muestran algunos de los problemas que mencionamos 
anteriormente, como una advertencia de que algo no va bien con tu análisis de regresión.

En primer lugar, hay algunos puntos que se encuentran fuera de la banda delimitada por las dos líneas punteadas en los valores residuales normalizados -3 y +3 (un rango que hipotéticamente debería cubrir 99,7% de los valores si los residuos tienen una distribución normal).

Entonces, la nube de puntos no está en absoluto dispersa al azar, mostrando diferentes varianzas a diferentes valores de la variable de predicción (el eje de abscisas) y se pueden detectar (puntos en línea recta, o los puntos centrales colocados en una especie de U).

El número medio de habitaciones es probablemente un buen predictor, pero no es no es la única causa, o hay que replanteársela como causa directa (el número de habitaciones indica una casa más grande, pero *¿qué pasa si las habitaciones son más pequeñas que la media?*)

### Predicciones con un modelo de regresión

Cuando introducimos los coeficientes en la fórmula de regresión, predecir es sólo cuestión de aplicar los nuevos datos al vector de coeficientes mediante una multiplicación matricial.


```python
# Escogemos el número de cuartos
RM = 5 
# Creamos un vector adecuado para insertar en el modelo
Xp = np.array([1,RM]) 
y_pred = fitted_model.predict(Xp)[0]*1000
# Realizamos la predicción
print("""
De acuerdo a nuestro modelos, 
si el número de cuartos es {}, 
entonces el valor de la casa 
será de ${:.2f}""".format(RM, y_pred))
```

    
    De acuerdo a nuestro modelos, 
    si el número de cuartos es 5, 
    entonces el valor de la casa 
    será de $10839.92
    

Un buen uso del método de predicción es proyectar las predicciones ajustadas en nuestro gráfico de dispersión anterior para permitirnos visualizar la dinámica de los precios con respecto a nuestro predictor, el número medio de habitaciones:


```python
x_range = [dataset['RM'].min(),dataset['RM'].max()] 
y_range = [dataset['target'].min(),dataset['target'].max()] 
scatter_plot = dataset.plot(kind='scatter', 
                            x='RM', y='target',
                            xlim=x_range, 
                            ylim=y_range,
                           alpha=0.25) 
meanY = scatter_plot.plot(x_range,
                          [dataset['target'].mean(),dataset['target'].mean()], 
                          '--', color='red', linewidth=1) 
meanX = scatter_plot.plot([dataset['RM'].mean(), dataset['RM'].mean()], 
                          y_range, '--', color='red', linewidth=1) 
regression_line = scatter_plot.plot(dataset['RM'], 
                                    fitted_values,
                                    '-',color='green', linewidth=2)
```


    
![png](output_76_0.png)
    


Además del método de predicción, la generación de las predicciones es bastante fácil con sólo utilizar la función `dot()` en NumPy.


```python
predictions_by_dot_product = np.dot(X,betas) 
print("Using the prediction method: {}".format(fitted_values[:10].to_numpy()))
print("Using betas and a dot product: {}".format(predictions_by_dot_product[:10]))
```

    Using the prediction method: [25.17574577 23.77402099 30.72803225 29.02593787 30.38215211 23.85593997
     20.05125842 21.50759586 16.5833549  19.97844155]
    Using betas and a dot product: [25.17574577 23.77402099 30.72803225 29.02593787 30.38215211 23.85593997
     20.05125842 21.50759586 16.5833549  19.97844155]
    

### Regresión con Scikit-learn 

Como hemos visto al trabajar con el paquete StatsModels, se puede construir un modelo lineal utilizando un paquete de aprendizaje automático más orientado como Scikit-learn. 


```python
"""
Usando el módulo `linear_model()`, podemos establecer un modelo de regresión lineal especificando que los predictores 
no deben ser normalizados y que nuestro modelo debe tener un sesgo:
"""
from sklearn import linear_model 
linear_regression = linear_model.LinearRegression(normalize=False, fit_intercept=True)
```


```python
"""
La preparación de los datos, en cambio, requiere el recuento de las observaciones y la preparación cuidadosa de la 
matriz del predictor para especificar sus dos dimensiones (si se deja como un vector, el procedimiento de ajuste error):
"""
observations = len(dataset) 
X = dataset['RM'].values.reshape((observations,1)) # X debe reformarse como una matrix renglón
print(X.shape)
y = dataset['target'].values # pero y seguirá siendo un vector
print(y.shape)
```

    (506, 1)
    (506,)
    


```python
"""
After completing all the previous steps, we can fit the model using the fit method:
"""
linear_regression.fit(X,y)
```




    LinearRegression()



Una característica muy conveniente del paquete Scikit-learn es que todos los modelos, sin importar su tipo de complejidad, comparten los mismos métodos. 


```python
"""
El método `fit()` se utiliza siempre para el ajuste y espera una X y una y (cuando el modelo es supervisado). 
En cambio, los dos métodos habituales para hacer una predicción exacta (siempre para la regresión) y su probabilidad 
(cuando el modelo es probabilístico) son `predict()` y `predict_proba()`, respectivamente.
"""
print(linear_regression.coef_) 
print(linear_regression.intercept_)
```

    [9.10210898]
    -34.67062077643857
    


```python
"""
Utilizando el método de predicción y cortando los 10 primeros elementos de la lista resultante, 
obtenemos los 10 primeros valores predichos:
"""
print (linear_regression.predict(X)[:10])
```

    [25.17574577 23.77402099 30.72803225 29.02593787 30.38215211 23.85593997
     20.05125842 21.50759586 16.5833549  19.97844155]
    


```python
"""
Como se ha visto anteriormente, si preparamos una nueva matriz y añadimos una constante, 
podemos calcular los resultados por nosotros mismos utilizando una simple multiplicación matriz-vector:
"""
Xp = np.column_stack((X,np.ones(observations))) 
v_coef = list(linear_regression.coef_) + [linear_regression.intercept_]
```


```python
"""
Como era de esperar, el resultado del producto nos proporciona las mismas estimaciones que el método de predicción:
"""
np.dot(Xp,v_coef)[:10]
```




    array([25.17574577, 23.77402099, 30.72803225, 29.02593787, 30.38215211,
           23.85593997, 20.05125842, 21.50759586, 16.5833549 , 19.97844155])



En este punto, sería natural cuestionar el uso de dicho módulo. En comparación con las funciones anteriores ofrecidas por Statsmodels, Scikit-learn parece ofrecer pocos resultados estadísticos, y uno aparentemente con muchas características de regresión lineal eliminadas.

 En realidad, ofrece exactamente lo que se necesita en la ciencia de los datos y tiene un rendimiento perfectamente rápido cuando se trata de grandes conjuntos de datos. 

Si estás trabajando en IPython, has la siguiente prueba para generar un gran conjunto de datos y comprobar el rendimiento de las dos versiones de la regresión lineal:


```python
# make_regression geenera un problema de regresión aleatorio
from sklearn.datasets import make_regression 
HX, Hy = make_regression(n_samples=10000000, n_features=1,n_targets=1,random_state=101)
```

Después de generar diez millones de observaciones de una sola variable, comience a medir utilizando la función mágica %%time para IPython.


```python
%%time 
sk_linear_regression = linear_model.LinearRegression(normalize=False,fit_intercept=True)
sk_linear_regression.fit(HX,Hy)
```

    Wall time: 2.32 s
    




    LinearRegression()




```python
%%time 
sm_linear_regression = sm.OLS(Hy,sm.add_constant(HX))
sm_linear_regression.fit()
```

    Wall time: 4.56 s
    




    <statsmodels.regression.linear_model.RegressionResultsWrapper at 0x26ceb01f6a0>



## Resumen

En este capítulo hemos presentado la regresión lineal como algoritmo de aprendizaje automático supervisado. 

Explicamos su forma funcional, su relación con las medidas estadísticas de la media y la correlación, e intentamos construir un modelo de regresión lineal simple sobre los datos de los precios de la vivienda en Boston. 

Después de hacer esto, finalmente echamos un vistazo a cómo funciona la regresión bajo el capó proponiendo sus formulaciones matemáticas clave y su traducción al código Python.


```python

```
